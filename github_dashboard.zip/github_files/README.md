# AI 미션룸 수료 현황 대시보드

## 데이터 업데이트 방법

### 비개발자도 쉽게! GitHub에서 직접 업로드

1. GitHub 저장소 접속
2. `data` 폴더 클릭
3. `latest.xlsx` 파일 클릭 → 우측 상단 연필(Edit) 아이콘 클릭
4. **"Upload file"** 선택 → 새 엑셀 파일 업로드 (파일명은 반드시 `latest.xlsx`)
5. 하단 **"Commit changes"** 클릭

→ 약 1~2분 후 GitHub Actions가 자동으로 `dashboard.json`을 생성하고 대시보드가 업데이트돼요!

## 저장소 구조

```
/
├── index.html                        ← 대시보드 (건드리지 않아도 됨)
├── generate_dashboard.py             ← 자동 실행 스크립트 (건드리지 않아도 됨)
├── data/
│   ├── latest.xlsx                   ← ✅ 이것만 교체하면 됨
│   └── dashboard.json                ← 자동 생성됨 (건드리지 않아도 됨)
└── .github/workflows/
    └── update.yml                    ← 자동화 설정 (건드리지 않아도 됨)
```

## 최초 설정 (한 번만)

1. 이 저장소의 Settings → Pages → Source: `main` branch, `/ (root)` 선택
2. Settings → Actions → General → Workflow permissions: **Read and write permissions** 체크
3. `data/latest.xlsx` 파일을 처음 업로드하면 끝!
